import { Component, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookmarkParserService, RawBookmark, OrganizedCategory } from './services/bookmark-parser.service';
import { GeminiService } from './services/gemini.service';
import { LoaderComponent } from './components/loader.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, LoaderComponent],
  templateUrl: './app.component.html'
})
export class AppComponent {
  private parserService = inject(BookmarkParserService);
  private geminiService = inject(GeminiService);

  // State
  rawBookmarks = signal<RawBookmark[]>([]);
  organizedBookmarks = signal<OrganizedCategory[]>([]);
  searchQuery = signal<string>('');
  isProcessing = signal<boolean>(false);
  error = signal<string | null>(null);
  dragOver = signal<boolean>(false);

  // Computed
  hasResults = computed(() => this.organizedBookmarks().length > 0);
  rawCount = computed(() => this.rawBookmarks().length);
  
  // Filter logic
  filteredBookmarks = computed(() => {
    const query = this.searchQuery().toLowerCase().trim();
    const categories = this.organizedBookmarks();

    if (!query) return categories;

    return categories.map(category => ({
      ...category,
      bookmarks: category.bookmarks.filter(b => 
        b.title.toLowerCase().includes(query) || 
        b.url.toLowerCase().includes(query)
      )
    })).filter(category => category.bookmarks.length > 0);
  });

  organizedCount = computed(() => this.organizedBookmarks().reduce((acc, cat) => acc + cat.bookmarks.length, 0));
  displayedCount = computed(() => this.filteredBookmarks().reduce((acc, cat) => acc + cat.bookmarks.length, 0));

  async onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      await this.processFile(input.files[0]);
    }
  }

  onSearch(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchQuery.set(target.value);
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.dragOver.set(true);
  }

  onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.dragOver.set(false);
  }

  async onDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.dragOver.set(false);
    
    if (event.dataTransfer?.files && event.dataTransfer.files.length > 0) {
      await this.processFile(event.dataTransfer.files[0]);
    }
  }

  async processFile(file: File) {
    this.error.set(null);
    this.isProcessing.set(true);
    this.rawBookmarks.set([]);
    this.organizedBookmarks.set([]);
    this.searchQuery.set(''); // Reset search on new file

    try {
      // 1. Parse HTML
      const bookmarks = await this.parserService.parseFile(file);
      if (bookmarks.length === 0) {
        throw new Error("No bookmarks found in the file. Make sure it's a valid Netscape Bookmark HTML file.");
      }
      this.rawBookmarks.set(bookmarks);

      // 2. Send to Gemini
      const organized = await this.geminiService.organizeBookmarks(bookmarks);
      this.organizedBookmarks.set(organized);

    } catch (err: any) {
      console.error(err);
      this.error.set(err.message || "An unexpected error occurred.");
    } finally {
      this.isProcessing.set(false);
    }
  }

  downloadExport() {
    const categories = this.organizedBookmarks();
    if (categories.length === 0) return;

    const htmlContent = this.parserService.generateNetscapeHTML(categories);
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'organized_bookmarks.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  reset() {
    this.rawBookmarks.set([]);
    this.organizedBookmarks.set([]);
    this.searchQuery.set('');
    this.error.set(null);
  }
}