import { Injectable } from '@angular/core';

export interface RawBookmark {
  title: string;
  url: string;
  id: string;
}

export interface OrganizedCategory {
  name: string;
  bookmarks: {
    title: string;
    url: string;
    originalId?: string;
  }[];
}

@Injectable({
  providedIn: 'root'
})
export class BookmarkParserService {

  async parseFile(file: File): Promise<RawBookmark[]> {
    const text = await file.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(text, 'text/html');
    const links = Array.from(doc.querySelectorAll('a'));

    return links.map((link, index) => ({
      title: link.textContent || link.getAttribute('href') || 'Untitled',
      url: link.getAttribute('href') || '',
      id: `bm-${index}`
    })).filter(b => b.url && !b.url.startsWith('place:')); // Filter out smart bookmarks
  }

  generateNetscapeHTML(categories: OrganizedCategory[]): string {
    const now = Math.floor(Date.now() / 1000);
    let html = `<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file.
     It will be read and overwritten.
     DO NOT EDIT! -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
`;

    for (const category of categories) {
      html += `    <DT><H3 ADD_DATE="${now}" LAST_MODIFIED="${now}">${this.escapeHtml(category.name)}</H3>\n`;
      html += `    <DL><p>\n`;
      for (const b of category.bookmarks) {
        html += `        <DT><A HREF="${this.escapeHtml(b.url)}" ADD_DATE="${now}">${this.escapeHtml(b.title)}</A>\n`;
      }
      html += `    </DL><p>\n`;
    }

    html += `</DL><p>`;
    return html;
  }

  private escapeHtml(unsafe: string): string {
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
}