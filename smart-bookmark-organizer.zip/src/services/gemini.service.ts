import { Injectable } from '@angular/core';
import { GoogleGenAI, Type, SchemaType } from "@google/genai";
import { RawBookmark, OrganizedCategory } from './bookmark-parser.service';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env['API_KEY']! });
  }

  async organizeBookmarks(bookmarks: RawBookmark[]): Promise<OrganizedCategory[]> {
    // If too many bookmarks, we might need to batch them.
    // For this demo, we'll take the first 100-150 to stay within context limits if needed, 
    // but Flash 2.0 has a huge context window so we can likely fit 1000+.
    // We will limit to 500 for safety and speed in this interactive demo.
    const limitedBookmarks = bookmarks.slice(0, 500); 
    
    const inputList = limitedBookmarks.map(b => `- URL: ${b.url}\n  Current Title: ${b.title}`).join('\n');

    const prompt = `
      You are an expert digital organizer.
      I have a list of browser bookmarks. 
      Please organize them into logical, distinct categories (e.g., "Development", "News", "Shopping", "Entertainment", "Tools", etc.).
      Also, RENAME the bookmarks to be clean, concise, and descriptive. Remove suffixes like " - Wikipedia", " - YouTube", or SEO junk.
      The output must be a JSON array of categories, each containing a list of bookmarks.
      
      Here are the bookmarks:
      ${inputList}
    `;

    const response = await this.ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "The name of the category (folder)" },
              bookmarks: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING, description: "The cleaned-up, concise title" },
                    url: { type: Type.STRING, description: "The original URL" }
                  },
                  required: ["title", "url"]
                }
              }
            },
            required: ["name", "bookmarks"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from AI");
    }
    
    try {
      return JSON.parse(text) as OrganizedCategory[];
    } catch (e) {
      console.error("Failed to parse JSON", text);
      throw new Error("Failed to parse organized bookmarks.");
    }
  }
}