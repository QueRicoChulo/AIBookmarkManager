import { Component } from '@angular/core';

@Component({
  selector: 'app-loader',
  standalone: true,
  template: `
    <div class="flex flex-col items-center justify-center space-y-4 p-8">
      <div class="relative w-16 h-16">
        <div class="absolute top-0 left-0 w-full h-full border-4 border-indigo-200 rounded-full animate-ping opacity-25"></div>
        <div class="absolute top-0 left-0 w-full h-full border-4 border-t-indigo-600 border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
      </div>
      <div class="text-center">
        <h3 class="text-lg font-semibold text-gray-800">Organizing your digital life...</h3>
        <p class="text-sm text-gray-500 animate-pulse">Analyzing URLs, cleaning titles, and creating folders.</p>
      </div>
    </div>
  `
})
export class LoaderComponent {}